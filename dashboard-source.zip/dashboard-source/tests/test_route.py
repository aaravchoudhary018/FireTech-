import unittest
from unittest.mock import patch
from api.route import normalize_route, fetch_route
class RouteTests(unittest.TestCase):
    def test_traffic_alignment_and_missing_coverage(self):
        route=normalize_route({'routes':[{'geometry':{'coordinates':[[1,2],[2,3],[3,4]]},'distance':12400,'duration':1320,'legs':[{'annotation':{'congestion':['heavy']}}]}]})
        self.assertEqual(route['congestion'],['heavy','unknown'])
        self.assertEqual(route['distance'],12400)
    def test_empty_route_rejected(self):
        with self.assertRaises(ValueError): normalize_route({'routes':[]})
    @patch.dict('os.environ',{},clear=True)
    def test_credentials_required(self):
        with self.assertRaisesRegex(ValueError,'MAPBOX_DIRECTIONS_TOKEN'):fetch_route()
