"""Local Python API and optional built React frontend. Run: python3 server.py"""
from pathlib import Path
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse
from api.route import handler

class LocalHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(Path(__file__).parent/'dist'), **kwargs)
    def do_GET(self):
        if urlparse(self.path).path == '/api/route':
            return handler.do_GET(self)
        if urlparse(self.path).path.startswith('/dashboard/'):
            self.path = self.path[len('/dashboard'):]
        return super().do_GET()

if __name__ == '__main__':
    print('Dashboard API / built preview: http://127.0.0.1:8003', flush=True)
    ThreadingHTTPServer(('127.0.0.1', 8003), LocalHandler).serve_forever()
