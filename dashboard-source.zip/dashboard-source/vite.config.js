import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
export default defineConfig({base:'/dashboard/',plugins:[react(),tailwindcss()],worker:{format:'es'},server:{proxy:{'/api':'http://127.0.0.1:8003'}}});
