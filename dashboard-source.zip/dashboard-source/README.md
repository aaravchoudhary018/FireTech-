# Routekind — Dark live journey dashboard

React + Tailwind CSS + Mapbox GL JS, with a small zero-dependency Python routing API. The opening screen follows the supplied reference: a large charcoal map, green/yellow/red road segments, a moving car, signal countdowns, and a floating four-column panel.

## 1. Run the complete demo

Install **Node.js 20.19+ or 22.12+** and **Python 3.9+**. Open a terminal in this folder:

```sh
npm install
npm run build
python3 server.py
```

Open **http://127.0.0.1:8003/**. No API credentials are required for the built demo. The supplied ZIP includes the built `dist/` folder, so you can also run `python3 server.py` immediately without installing Node.

To edit with hot reload, start Python in one terminal, then run this in another:

```sh
npm run dev
```

Open the Vite URL, normally **http://127.0.0.1:5173/**. Vite forwards `/api/route` to Python on port 8003. Close with Ctrl+C.

## 2. Enable the Mapbox APIs

1. Create/sign into your [Mapbox account](https://account.mapbox.com/). Configure billing for the APIs you intend to use; requests/map loads can incur charges. Check your account's current pricing and usage limits.
2. Create a public **`pk.`** token for the browser map, using the normal map/style reading scopes. Add your development and production URLs to its allowed URLs. A browser token is visible to visitors by design. Never put a secret `sk.` token in a `VITE_` variable.
3. Copy `.env.example` to `.env.local` and replace the placeholder:

```env
VITE_MAPBOX_TOKEN=pk.YOUR_PUBLIC_MAP_TOKEN
```

4. Configure a separate token that can call Directions on the Python server. It is only read from the server environment. Do not apply browser-origin restrictions to a server token without checking that server requests are allowed. Do not commit either environment file. In macOS/Linux:

```sh
export MAPBOX_DIRECTIONS_TOKEN='YOUR_SERVER_DIRECTIONS_TOKEN'
python3 server.py
```

PowerShell:

```powershell
$env:MAPBOX_DIRECTIONS_TOKEN = 'YOUR_SERVER_DIRECTIONS_TOKEN'
python server.py
```

5. Restart Vite after changing its environment; rebuild if serving `dist/`:

```sh
npm run build
```

6. Select **Live Mapbox** in the dashboard. Python calls Directions, and React renders the returned geometry on Mapbox's `dark-v11` style. Credentials are never pasted into the dashboard. If the server request fails, an error is shown; the last route or the labeled demo remains available.

The two approximate endpoints are Indiranagar **[77.6408, 12.9784]** and RMZ Ecospace **[77.6951, 12.9149]**, always in **longitude, latitude** order. For precise building entrances, replace `COORDINATES` in `api/route.py` with coordinates verified by your team.

## 3. Route and traffic integration

The fixed Python endpoint is `GET /api/route`. The upstream call is:

```text
https://api.mapbox.com/directions/v5/mapbox/driving-traffic/
77.6408,12.9784;77.6951,12.9149
?geometries=geojson&overview=full
&annotations=congestion,distance,duration
&steps=false&alternatives=false&access_token=SERVER_TOKEN
```

The URL is assembled in code with URL encoding. The token stays in the Python process and is omitted from error messages. `normalize_route()` returns this shape:

```json
{
  "source": "mapbox",
  "coordinates": [[77.6408, 12.9784], [77.6445, 12.9765]],
  "congestion": ["moderate"],
  "distance": 12400,
  "duration": 1320,
  "updated_at": "2026-10-10T00:00:00+00:00"
}
```

One traffic annotation corresponds to each consecutive coordinate pair. React creates one GeoJSON LineString per pair. The line layer reads a `color` property: low = green, moderate = yellow, heavy/severe = red, unknown = grey. Missing congestion data stays unknown. Coverage and freshness depend on the provider; a live route does not guarantee live congestion measurements for every Bengaluru road.

React requests a refresh every **120 seconds**, with overlap protection and request cancellation when switching mode/unmounting. Python caches successful responses for 120 seconds per process; serverless instances have separate caches. Distance and ETA change to provider values in live mode. The Refresh button requests the endpoint but still respects the server cache. To force a different refresh cadence, change both sides and account for API cost.

This version chooses Mapbox for both tiles and routing. It does not require Google Maps. Official integration references:

- [Mapbox GL JS setup](https://docs.mapbox.com/mapbox-gl-js/guides/get-started/)
- [Directions API, driving-traffic and annotations](https://docs.mapbox.com/api/navigation/directions/)
- [Mapbox token permissions and restrictions](https://docs.mapbox.com/accounts/guides/tokens/)
- [Tailwind's Vite integration](https://tailwindcss.com/docs/installation/using-vite)

## 4. Car movement and traffic-light countdowns

`useJourney.js` maintains a clock with a cleaned-up 100 ms timer. `geometry.js` interpolates the vehicle by route-segment distance and calculates its bearing. The demonstration completes in **180 seconds**; it is presentation time, unrelated to the route ETA. Use Pause/Resume or Restart. Signals cycle through 45 seconds red, 35 seconds green, and 10 seconds yellow with independent offsets.

These signal markers are placed at sample fractions along the route. They are **not actual traffic-light locations or government signal feeds**. Routing APIs do not supply the countdown used here. The car is simulated rather than tracked GPS. The ₹42 savings and 98.4% safety index are fixed reference values, explicitly illustrative and not calculated safety assessments. A live route mode does not change these into real data.

### Optional real WebSocket upgrade

A timer is sufficient for this requested simulation, so no WebSocket server is required. For a real shared trip, run a persistent authenticated WebSocket service outside the Vercel Python function. Send authorized participants messages such as:

```json
{"type":"vehicle_position","tripId":"trip_123","longitude":77.66,"latitude":12.95,"timestamp":"2026-10-10T00:00:00Z"}
```

Replace `pointAlong(...).position` with the latest validated vehicle position, reject stale timestamps, reconnect with exponential backoff, and retain a visibly stale last position during disconnection. Real signal countdowns require a separate authorized signal-phase feed. Do not claim the current demo is receiving WebSocket or GPS data.

## 5. Deploy as its own Vercel project

Upload **the contents of this folder** into a separate repository, or choose this folder as the Root Directory of a monorepo project. Keep the existing carpool booking site as its current project.

- Framework: **Vite**.
- Build: `npm run build`.
- Output: `dist`.
- `api/route.py` becomes the Python function for `/api/route`.
- Set `VITE_MAPBOX_TOKEN` and `MAPBOX_DIRECTIONS_TOKEN` in Vercel environment settings, then redeploy.
- Add the final domain to your public map token's allowed URLs.

The committed `vercel.json` supplies build/output settings. The local `server.py` is only the development/built-preview server. Do not upload `.env.local` or `node_modules`. For public production, add authentication, rate limiting and monitoring to `/api/route`; the current endpoint is a fixed public demo route. No participant data is stored or broadcast.

## 6. Source files and validation

- `src/App.jsx`: dashboard layout and controls, using Tailwind utility classes.
- `src/MapView.jsx`: Mapbox layers, markers, and the API-free illustrative SVG map.
- `src/style.css`: dark colors, markers, stats panel, mobile layout.
- `src/useJourney.js`: clock, pause, route polling, cancellation and errors.
- `src/geometry.js`: interpolation, bearing, traffic features and signal phase math.
- `src/demo.js`: sample route and signal definitions.
- `api/route.py`: cached Mapbox Directions integration and response normalization.
- `server.py`: local Python server.
- `.env.example`: environment setup.

```sh
npm test
python3 -m unittest discover -s tests -v
npm run build
```

The routing tests use fake API responses; they never incur provider charges. A live token and provider response are required to verify the live API end to end. Frontend demo and real-data integration code are both included in full.
