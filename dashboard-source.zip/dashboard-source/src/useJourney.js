import {useEffect,useRef,useState} from 'react';
import {DEMO} from './demo';
export default function useJourney(){
 const [mode,setMode]=useState('demo'),[route,setRoute]=useState(DEMO),[error,setError]=useState(''),[loading,setLoading]=useState(false),[paused,setPaused]=useState(false),[elapsed,setElapsed]=useState(0),[refreshKey,setRefreshKey]=useState(0);
 const [token,setToken]=useState(import.meta.env.VITE_MAPBOX_TOKEN||'');
 useEffect(()=>{const controller=new AbortController();fetch('/api/map-config',{signal:controller.signal}).then(r=>r.ok?r.json():{}).then(data=>{if(typeof data.public_token==='string'&&data.public_token.startsWith('pk.'))setToken(data.public_token);}).catch(()=>{});return()=>controller.abort();},[]);const mounted=useRef(false);
 useEffect(()=>{mounted.current=true;return()=>{mounted.current=false;};},[]);
 useEffect(()=>{if(paused)return;let previous=performance.now();const interval=setInterval(()=>{const now=performance.now();setElapsed(e=>e+(now-previous)/1000);previous=now;},100);return()=>clearInterval(interval);},[paused]);
 useEffect(()=>{
  if(mode==='demo'){setRoute(DEMO);setError('');setLoading(false);return;}
  const controller=new AbortController();let busy=false;
  async function fetchRoute(){if(busy)return;busy=true;setLoading(true);try{const response=await fetch('/api/route',{signal:controller.signal});const value=await response.json();if(!response.ok)throw new Error(value.error||'Routing is unavailable.');if(!Array.isArray(value.coordinates)||value.coordinates.length<2)throw new Error('Invalid routing response.');if(mounted.current&&!controller.signal.aborted){setRoute(value);setError('');}}catch(err){if(err.name!=='AbortError'&&!controller.signal.aborted)setError(err.message);}finally{busy=false;if(!controller.signal.aborted)setLoading(false);}}
  fetchRoute();const interval=setInterval(fetchRoute,120000);return()=>{controller.abort();clearInterval(interval);};
 },[mode,refreshKey]);
 useEffect(()=>{setElapsed(0);},[mode]);
 return {mode,setMode,route,error,loading,paused,setPaused,elapsed,restart:()=>setElapsed(0),refresh:()=>setRefreshKey(k=>k+1),token};
}
