export const COLORS={low:'#81b991',moderate:'#e8c477',heavy:'#d67e76',severe:'#d67e76',unknown:'#8895a1'};
export function length(a,b){const rad=Math.PI/180;return Math.hypot((b[0]-a[0])*Math.cos((a[1]+b[1])/2*rad),b[1]-a[1]);}
export function pointAlong(coords,fraction){
 if(!coords?.length) return {position:[0,0],angle:0};
 if(coords.length===1)return {position:coords[0],angle:0};
 const lengths=coords.slice(1).map((p,i)=>length(coords[i],p));
 const total=lengths.reduce((a,b)=>a+b,0);let target=Math.max(0,Math.min(1,fraction))*total;
 for(let i=0;i<lengths.length;i++){
  if(target<=lengths[i]||i===lengths.length-1){const t=lengths[i]?target/lengths[i]:0;const a=coords[i],b=coords[i+1];return {position:[a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t],angle:Math.atan2((b[0]-a[0])*Math.cos(a[1]*Math.PI/180),b[1]-a[1])*180/Math.PI};}target-=lengths[i];
 }
}
export function trafficFeatures(route){return {type:'FeatureCollection',features:route.coordinates.slice(1).map((p,i)=>({type:'Feature',properties:{color:COLORS[route.congestion[i]]||COLORS.unknown},geometry:{type:'LineString',coordinates:[route.coordinates[i],p]}}))};}
export function signalAt(elapsed,offset){const cycle=90,phase=(elapsed+offset)%cycle;return phase<45?{color:'red',remaining:Math.ceil(45-phase)}:phase<80?{color:'green',remaining:Math.ceil(80-phase)}:{color:'yellow',remaining:Math.ceil(90-phase)};}
