// Illustrative coordinates, not a navigation-grade route.
export const DEMO={source:'demo',distance:12400,duration:1320,updated_at:null,coordinates:[[77.6408,12.9784],[77.6445,12.9765],[77.6465,12.9684],[77.6508,12.9609],[77.6602,12.9534],[77.6695,12.9495],[77.6802,12.9415],[77.6862,12.9298],[77.6932,12.9215],[77.6951,12.9149]],congestion:['low','moderate','heavy','heavy','low','moderate','low','heavy','low']};
export const SIGNALS=[{id:'s1',fraction:.2,offset:0},{id:'s2',fraction:.4,offset:10},{id:'s3',fraction:.62,offset:55},{id:'s4',fraction:.82,offset:0}];
